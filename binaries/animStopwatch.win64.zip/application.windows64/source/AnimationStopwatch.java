import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Map; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class AnimationStopwatch extends PApplet {




ControlP5 cp5;
Knob fpsKnob;
boolean playing = false;
HashMap<Integer, Integer> events = new HashMap<Integer, Integer>();
int currentFrame = 0;

float textX = 25;

public void setup()
{
  
  frameRate(24);
  cp5 = new ControlP5(this);
  fpsKnob = cp5.addKnob("Frame_Rate").
  setRange(1,140).setValue(24).
  setPosition(width-120,30).
  setRadius(50).
  setDecimalPrecision(1);
}

public void draw()
{
  background(20);
  
  pushMatrix();
  // draw a little spinning tick
  noFill();
  strokeWeight(2);
  stroke((playing)? 0xffA1CE9E : 0xffCE969D);
  translate(width-20,height-20);
  ellipse(0,0,22,22);
  
  rotate(millis()*0.01f);
  fill(100);
  rect(-1,0,2,10);
  
  popMatrix();
  
  if (playing) {
    currentFrame++;
  }
  textSize(14);
  text("Hit SPACE to start/stop. Any other key to add an event :)", textX, 30);
  
  textSize(50);
  text("frame: "+currentFrame, textX, 100);

  textSize(20);
  for (int i = 0; i<events.size(); i++) {
    textSize(14);
    float y = 150 + (20*i);
    fill(100);
    text(i + "  -  -  -  -  -  -  -  -",textX,y);
    textSize(20);
    fill(255);
    text(events.get(i), textX+200, y);
  }
}

public void keyPressed()
{
  println(keyCode);
  switch(keyCode) {
  default:
    addEvent();
    break;
  case 32:
    togglePlay();
    break;
  }
}

public void togglePlay()
{
  if(!playing && currentFrame>0){
   reset();
  }
  playing = !playing;
}

public void reset()
{
 events = new HashMap<Integer, Integer>();
 currentFrame = 0;
}
public void addEvent()
{
  if (playing) {
    events.put(events.size(), currentFrame);
  }
}

public void Frame_Rate(int n)
{
 frameRate(n); 
}
  public void settings() {  size(600, 800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "AnimationStopwatch" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
